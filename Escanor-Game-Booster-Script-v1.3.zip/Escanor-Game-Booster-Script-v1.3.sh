#!/system/bin/sh
echo ""
sleep 0.5
echo ""
echo " [ Information About ] "
sleep 1
echo "PuppieGaming "
echo " DEVELOPER : @AljoPH "
sleep 1
echo " Escanor Game Booster Script v1.3 "
sleep 1
echo ""
echo " [ Check Your Device ] "
echo "• ID Device    » $(getprop ro.product.model)"
sleep 1.5
echo "• ID Brand     » $(getprop ro.product.system.brand)"
sleep 1.5
echo "• ID Model     » $(getprop ro.build.product)"
sleep 1.5
echo "• ID Kernel    » $(uname -r)"
sleep 1.5
echo "• ID Chipset   » $(getprop ro.product.board)"
sleep 5
echo ""
echo " [ SUPPORT ] "
sleep 1
echo " PuppieGaming "
sleep 1
echo ""
echo " > Applying Script To The Device < "
sleep 5
echo "[■□□□□□□□□□] 10% "
sleep 1
echo "[■■□□□□□□□□] 20% "
sleep 2
echo "[■■■□□□□□□□] 30% "
sleep 1
echo "[■■■■□□□□□□] 40% "
sleep 2
echo "[■■■■■□□□□□] 50% "
sleep 1
echo "[■■■■■■□□□□] 60% "
sleep 2
echo "[■■■■■■■□□□] 70% "
sleep 1
echo "[■■■■■■■■□□] 80% "
sleep 2
echo "[■■■■■■■■■□] 90% "
sleep 5
echo "[■■■■■■■■■■] 100% "
sleep 5
echo ""
apply_string () {
cmd game mode performance com.mobile.legends
cmd game mode performance com.dts.freefireth
cmd game mode performance com.tencent.ig
cmd game mode performance com.dts.freefiremax
cmd game mode performance com.ea.gp.fifamobile
cmd game mode performance com.activision.callofduty.shooter
cmd game mode performance com.ForgeGames.SpecialForcesGroup2
cmd power set-fixed-performance-mode-enabled true
cmd activity kill-all
cmd thermalservice override-status 0
settings put system peak_refresh_rate Infinity

settings put system max_refresh_rate Infinity

settings put system min_refresh_rate Infinity

settings put global peak_refresh_rate Infinity

settings put global max_refresh_rate Infinity

settings put global min_refresh_rate Infinity

setprop debug.sf.early.app.duration 34650000

setprop debug.sf.early.sf.duration 33600000

setprop debug.sf.earlyGl.app.duration 44100000

setprop debug.sf.earlyGl.sf.duration 28350000

setprop debug.sf.enable_hwc_vds 0

setprop debug.sf.latch_unsignaled 1

setprop debug.sf.late.app.duration 43050000

setprop debug.sf.late.sf.duration 22050000

setprop debug.sf.use_phase_offsets_as_durations 1

setprop debug.sf.early.app.duration 34650000

setprop debug.sf.early.sf.duration 33600000

setprop debug.sf.earlyGl.app.duration 44100000

setprop debug.sf.earlyGl.sf.duration 28350000

setprop debug.sf.enable_hwc_vds 0

setprop debug.sf.latch_unsignaled 1

setprop debug.sf.late.app.duration 43050000

setprop debug.sf.late.sf.duration 22050000

setprop debug.sf.use_phase_offsets_as_durations 1

setprop debug.sf.kernel_idle_timer_update_overlay 10ms

setprop debug.sf.high_fps_early_phase_offset_ns 1097689

setprop debug.sf.high_fps_early_gl_phase_offset_ns 102837

setprop debug.sf.late.sf.duration 10ms

setprop debug.sf.add_layer_fail_log_threshold 10ms

setprop debug.sf.layer_history_trace 1

setprop debug.sf.vsp_trace 1

setprop debug.sf.send_late_power_session_hint false

setprop debug.sf.gpu_freq_index 7

setprop debug.sf.cpu_freq_index 7

setprop debug.sf.mem_freq_index 7

setprop debug.hwui.skip_empty_damage true

setprop debug.enabletr true

setprop debug.hwui.level 4

setprop debug.hwui.fps_divisor -1

setprop debug.rs.disable_expand true

setprop debug.rs.force_finish 1

setprop debug.rs.noprofile 1

debug.rs.dump_bitcode 0

debug.rs.notextures true

debug.rs.use_fast_math 1

debug.egl.swapintervaldelay 16ms

debug.egl.swapinterval 1

setprop debug.heat_suppression 0

setprop debug.vk.layers_enabled true

setprop debug.vk.layers_support 120

setprop debug.vk.swap_buffers 15

setprop debug.sf.kernel_idle_timer_update_overlay 10ms

setprop debug.sf.high_fps_early_phase_offset_ns 1097689

setprop debug.sf.high_fps_early_gl_phase_offset_ns 102837

setprop debug.sf.late.sf.duration 10ms

setprop debug.sf.add_layer_fail_log_threshold 10ms

setprop debug.sf.layer_history_trace 1

setprop debug.sf.vsp_trace 1
}
> /dev/null 2>&1
echo ""
echo "Successfully Injected"
echo "Enjoy Your Game"