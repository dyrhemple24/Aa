#!/system/bin/sh
echo ""
sleep 0.5
echo ""
echo " [ Information About ] "
sleep 1
echo "PuppieGaming "
echo " DEVELOPER : @AljoPH "
sleep 1
echo " Escanor Game Booster Premium Script v1.0 "
sleep 1
echo ""
echo " [ Check Your Device ] "
echo "• ID Device    » $(getprop ro.product.model)"
sleep 1.5
echo "• ID Brand     » $(getprop ro.product.system.brand)"
sleep 1.5
echo "• ID Model     » $(getprop ro.build.product)"
sleep 1.5
echo "• ID Kernel    » $(uname -r)"
sleep 1.5
echo "• ID Chipset   » $(getprop ro.product.board)"
sleep 5
echo ""
echo " [ SUPPORT ] "
sleep 1
echo " PuppieGaming "
sleep 1
echo ""
echo " > Applying Script To The Device < "
sleep 5
echo "[■□□□□□□□□□] 10% "
sleep 1
echo "[■■□□□□□□□□] 20% "
sleep 2
echo "[■■■□□□□□□□] 30% "
sleep 1
echo "[■■■■□□□□□□] 40% "
sleep 2
echo "[■■■■■□□□□□] 50% "
sleep 1
echo "[■■■■■■□□□□] 60% "
sleep 2
echo "[■■■■■■■□□□] 70% "
sleep 1
echo "[■■■■■■■■□□] 80% "
sleep 2
echo "[■■■■■■■■■□] 90% "
sleep 5
echo "[■■■■■■■■■■] 100% "
sleep 5
echo ""
apply_string () {
cmd game mode performance com.mobile.legends
cmd game mode performance com.dts.freefireth
cmd game mode performance com.tencent.ig
cmd game mode performance com.dts.freefiremax
cmd game mode performance com.ea.gp.fifamobile
cmd game mode performance com.activision.callofduty.shooter
cmd game mode performance com.ForgeGames.SpecialForcesGroup2
settings put system qti.inputopts.enable true
settings put system qti.inputopts.movetouchslop 0.1
settings put global DragMinSwitchSpeed 99999.0px/s
settings put global SwipeMaxWidthRatio 0.1
settings put system MovementSpeedRatio 0.1
settings put system ZoomSpeedRatio 0.1
settings put system SwipeTransitionAngleCosine 3.6
settings put system mot.proximity.distance 0.1
settings put system PointerVelocityControlParameters 0.1
settings put system lowThreshold 0
settings put system highThreshold 0
settings put system VirtualKeyQuietTime 0
settings put system KeyRepeatDelay 0
settings put system KeyRepeatTimeout 0
settings put system device.internal 0.1
setprop debug.performance.tuning 0.1
setprop debug.egl.swapinterval 90
settings put secure dev.pm.dyn_samplingrate 0.1
settings put secure r.setframepace 0.120
settings put system view.scroll_friction 0.0000.1
settings put system touchscreen_sensitivity 0.10
settings put system touchscreen_min_press_time 50
settings put system touchscreen_hevoring 0
settings put system touchscreen_gesture_mode 0.1
settings put system touchscreen_pointer_speed 0.15
settings put system touchscreen_pressure_calibration 0.1023
settings put system touchscreen_sensitivity_mode 3
settings put system touchscreen_threshold 9
settings put system touchscreen_sensitivity_threshold 9
settings put system touchscreen_double_tap_speed 75
settings put system touchscreen_long_press_timeout 300
settings put system touchscreen_sensitivity_scale 0.1.5
settings put system qti.inputopts.enable true
settings put system qti.inputopts.movetouchslop 0.6
settings put system sf.delayedtouches 0
settings put system touch.orientationAware 0.1
settings put system SurfaceOrientation auto
settings put system touch.size.calibration auto
settings put system touch.size.scale auto
settings put system touch.size.isSummed 0.1
settings put system touch.orientation.calibration auto
settings put system touch.distance.calibration auto
settings put system touch.deviceType auto
settings put system touch.distance.scale auto
settings put system touch.coverage.calibration octagram
settings put system touch.pressure.scale auto
settings put system touch.gesturemode spots
settings put system MultitouchMinDistance auto
settings put system MultitouchSettleInterval 0ms
settings put system MovementSpeedRatio auto
settings put system pm.dyn_samplingrate 9999999999999999999999999999
settings put system touch.pressure.calibration auto
settings put system scroll.accelerated.hw true
settings put system ui.hwframes 9999999999999999999999999999
settings put system force_high_end_gfx 0.1
settings put system view.scroll_friction auto
settings put system min_pointer_dur auto
settings put system sf.disable_smooth_effect true
settings put system multi_touch_enabled true
settings put system max_num_touch auto
settings put system view.touch_slop 0dp
settings put system maxeventspersec 9999999999999999999999999999
settings put system scrollingcache 3
settings put system resampler.quality 255
settings put system touch.sampling rate 720
settings put system adaptive_touch_sensitivity speed
settings put system touch.orientationAware 0
settings put system PressureForID 0.00.1
settings put system QuietInterval 0.0.1ms
settings put system MultitouchMinDistance 0.1px
settings put system MultitouchSettleInterval 0.0.1ms
settings put system AIM_SENSITIVITY_TRANSITION_TIME GRADUAL
settings put system APP_SWITCH_DELAY_TIME false
settings put system AbsoluteXForID SpeedForID
settings put system AccelerationX true
settings put system AccelerationY true
settings put system DoubleTouch OEM
settings put system TapInterval 0.1ms
settings put system TapSlop 0.1px
settings put system PowerbuttonTapping 0
settings put system touch.assistant.enabled 0
settings put system type.touch_speed true
settings put system view.touch_slop 5
settings put system MovementSpeedRatio 0.8
settings put system accuracy.control 0.1
settings put system view_scroll_friction 0.10
settings put secure multi_press_timeout 0.10.10
settings put secure long_press_timeout 0.10.10
settings put global KeyRepeatDelay 0
settings put global KeyRepeatTimeout 0
settings put global LOSS_OF_FOCUS_BY_MOUSE_MOVEMENT DISABLED
settings put global MOUSEX_AIM_LEVEL 95%
settings put global window_animation_scale 0.3
settings put global transition_animation_scale 0.3
settings put global animator_duration_scale 0.3
settings put global fstrim_mandatory_interval 86400000
settings put system aimassist true
settings put system aimassist 999.999
settings put system aim assist true
settings put system aim assist 999.999
settings put system aimlock true
settings put system aimlock 999.999
settings put system aim lock true
settings put system aim lock 999.999
settings put system aimbot true
settings put system aimbot 999.999
settings put system aim bot true
settings put system aim bot 999.999

game-touchscreen-boost 1

screenPoint.X 499

screenPoint.Y 999

game-touchscreen-boost 1

persist-sys-mod performance

configure_game_sensitivity OEM

persist.preload.common 1

settings game-touchscreen-boost 1

settings screenPoint.X 499

settings screenPoint.Y 999

settings game-touchscreen-boost 1

settings persist-sys-mod performance

settings configure_game_sensitivity OEM

settings persist.preload.common 1

setprop game-touchscreen-boost 1

setprop screenPoint.X 499

setprop screenPoint.Y 999

setprop game-touchscreen-boost 1

setprop persist-sys-mod performance

setprop configure_game_sensitivity OEM

setprop persist.preload.common 1
}
> /dev/null 2>&1
echo ""
echo "Successfully Injected"
echo "Enjoy Your Game"